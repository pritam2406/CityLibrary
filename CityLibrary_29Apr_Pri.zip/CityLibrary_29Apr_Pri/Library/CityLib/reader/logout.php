<?php
session_start();//session is a way to store information (in variables) to be used across multiple pages.
session_destroy();
#header("Location: user-login.php");//use for the redirection to some page
$host  = $_SERVER['HTTP_HOST'];
$uri   = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
$extra = '../user-login.php';
header("Location: http://$host$uri/$extra");
?>
