<?php
session_start();

if(isset($_GET['id'])){
    $id = $_GET['id'];
    $cartBorrow = $_SESSION['cartBorrow'];
    if($cartBorrow == null)
    {
        $cartBorrow = array();
    }
    $index = 0;
    foreach ($cartBorrow as $row)
    {
        if($row['cartID'] == $id)
        {
            unset( $_SESSION['cartBorrow'][$index]);
            break;
        }
        $index = $index + 1;
    }

    $cartReserve = $_SESSION['cartReserve'];
    if($cartReserve == null)
    {
        $cartReserve = array();
    }
    $index = 0;
    foreach ($cartReserve as $row)
    {
        if($row['cartID'] == $id)
        {
            unset( $_SESSION['cartReserve'][$index]);
            break;
        }
        $index = $index + 1;
    }
    header('location:cart.php');

}

?>
