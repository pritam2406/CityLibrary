<?php
include('../DataManager/ReaderHelper.php');
$borrowNumber = $_GET['borrowNo'];
ReaderHelper::returnDocs($borrowNumber);
header('location:reader-borrow-list.php');
?>
