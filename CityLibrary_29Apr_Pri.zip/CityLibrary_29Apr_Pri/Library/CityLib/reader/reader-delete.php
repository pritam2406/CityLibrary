<?php
include('../DataManager/ReaderHelper.php');
$RID = $_GET['rid'];
ReaderHelper::deleteReader($RID);
header('location:logout.php');
?>
