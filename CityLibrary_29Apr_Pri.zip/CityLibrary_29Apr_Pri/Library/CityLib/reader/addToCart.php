<?php

session_start();
if(isset($_GET['borrowList'])){

    if($_SESSION['cartID'] == null)
    {
        $_SESSION['cartID'] = 0;
    }
    $_SESSION['cartID'] =  $_SESSION['cartID'] + 1;

    $dicRow = unserialize($_GET['borrowList']);
    $dicRow['cartID'] = $_SESSION['cartID'];

    if($_SESSION['cartBorrow'] == null)
    {
        $_SESSION['cartBorrow'] = array();
    }
    array_push($_SESSION['cartBorrow'], $dicRow);

    header('location:dashboard.php');

    echo '<pre>';
    print_r($_SESSION['cartBorrow']);
    echo '</pre>';
}
if(isset($_GET['reserveList'])){

    if($_SESSION['cartID'] == null)
    {
        $_SESSION['cartID'] = 0;
    }
    $_SESSION['cartID'] =  $_SESSION['cartID'] + 1;

    $dicRow = unserialize($_GET['reserveList']);
    $dicRow['cartID'] = $_SESSION['cartID'];

    if($_SESSION['cartReserve'] == null)
    {
        $_SESSION['cartReserve'] = array();
    }
    array_push($_SESSION['cartReserve'], $dicRow);

    header('location:dashboard.php');

    echo '<pre>';
    print_r($_SESSION['cartReserve']);
    echo '</pre>';
}

?>