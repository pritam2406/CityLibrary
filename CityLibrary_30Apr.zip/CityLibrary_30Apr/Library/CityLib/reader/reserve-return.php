<?php
include('../DataManager/ReaderHelper.php');
$reserveNumber = $_GET['reserveNo'];
ReaderHelper::returnReservedDocs($reserveNumber);
header('location:reader-reserve-list.php');
?>
