<?php
session_start();

include('include/config.php');
include('include/checklogin.php');
include('../DataManager/ReaderHelper.php');

check_login();
$cartBorrow = null;
if (isset($_SESSION['cartBorrow'])) {
    $cartBorrow = $_SESSION['cartBorrow'];
}
$cartReserve = null;
if (isset($_SESSION['cartReserve'])) {
    $cartReserve = $_SESSION['cartReserve'];
}

$userMobileNum = $_SESSION['login'];
$sql = "SELECT * FROM users WHERE USER_MOBILE_NO = $userMobileNum";
$result = mysqli_query($con, $sql);
$row1 = mysqli_fetch_assoc($result);
$uid = $row1['RID'];
#var_dump($uid);

#TODOOOOO
#'BID' 'DOCID' 'PUBLISHERID' 'TITLE' 'PDATE' 'PUBNAME' 'ADDRESS' 'COPYNO' 'POSITION' 'LNAME' 'LOCATION'

#Borrow
$docCopiesBorrow = array();
if ($cartBorrow != null) {
    foreach ($cartBorrow as $row) {
        $data = [
            'DOCID' => $row['DOCID'],
            'COPYNO' => $row['COPYNO'],
            'BID' => $row['BID'],
            'POSITION' => "",
        ];
        $docCopy = new DocumentCopyData($data);
        array_push($docCopiesBorrow, $docCopy);
    }
}
if (count($docCopiesBorrow) > 0) {
    ReaderHelper::checkoutDocs($docCopiesBorrow, $uid);
}
#Reserve
$docCopiesReserve = array();
if ($cartReserve != null) {
    foreach ($cartReserve as $row) {
        $data = [
            'DOCID' => $row['DOCID'],
            'COPYNO' => $row['COPYNO'],
            'BID' => $row['BID'],
            'POSITION' => "",
        ];
        $docCopy = new DocumentCopyData($data);
        array_push($docCopiesReserve, $docCopy);
    }
}

if (count($docCopiesReserve) > 0) {
    ReaderHelper::reserveDocs($docCopiesReserve, $uid);
}
$_SESSION['cartBorrow'] = array();
$_SESSION['cartReserve'] = array();
header('location:dashboard.php');
?>
