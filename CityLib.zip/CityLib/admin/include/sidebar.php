<div class="sidebar app-aside" id="sidebar">
				<div class="sidebar-container perfect-scrollbar">

<nav>
						
						<!-- start: MAIN NAVIGATION MENU -->
						<div class="navbar-title">
							<span>Main Navigation</span>
						</div>
						<ul class="main-navigation-menu">
							<li>
								<a href="dashboard.php">
									<div class="item-content">
										<div class="item-media">
											<i class="ti-home"></i>
										</div>
										<div class="item-inner">
											<span class="title"> Dashboard </span>
										</div>
									</div>
								</a>
							</li>
							<li>
								<a href="javascript:void(0)">
									<div class="item-content">
										<div class="item-media">
											<i class="ti-user"></i>
										</div>
										<div class="item-inner">
											<span class="title"> Readers </span><i class="icon-arrow"></i>
										</div>
									</div>
								</a>
								<ul class="sub-menu">
									<li>
										<a href="add-new-reader.php">
											<span class="title"> Add a  New Reader </span>
										</a>
									</li>
									
								</ul>
								</li>

				<li>
								<a href="javascript:void(0)">
									<div class="item-content">
										<div class="item-media">
											<i class="ti-user"></i>
										</div>
										<div class="item-inner">
											<span class="title"> Branches </span><i class="icon-arrow"></i>
										</div>
									</div>
								</a>
								<ul class="sub-menu">
									
									<li>
										<a href="show-branches.php">
											<span class="title"> See Branches </span>
										</a>
									</li>
                                    <li>
                                        <a href="add-new-branch.php">
                                            <span class="title"> Add New Branch </span>
                                        </a>
                                    </li>
									
								</ul>
								</li>
								<li>
								<a href="javascript:void(0)">
									<div class="item-content">
										<div class="item-media">
											<i class="ti-user"></i>
										</div>
										<div class="item-inner">
											<span class="title"> Person </span><i class="icon-arrow"></i>
										</div>
									</div>
								</a>
								<ul class="sub-menu">
									<li>
										<a href="add-new-publisher.php">
											<span class="title"> Add New Publisher </span>
										</a>
									</li>
                                    <li>
                                        <a href="add-new-person.php">
                                            <span class="title"> Add New Person </span>
                                        </a>
                                    </li>
									
								</ul>
								</li>

                            <li>
                                <a href="javascript:void(0)">
                                    <div class="item-content">
                                        <div class="item-media">
                                            <i class="ti-file"></i>
                                        </div>
                                        <div class="item-inner">
                                            <span class="title"> Documents </span><i class="icon-arrow"></i>
                                        </div>
                                    </div>
                                </a>
                                <ul class="sub-menu">

                                    <li>
                                        <a href="add-document-copy-to-branch.php">
                                            <span class="title"> Add a Document Copy to a Branch </span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="add-new-book.php">
                                            <span class="title"> Create New Book </span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="add-journal-volume.php">
                                            <span class="title"> Create Journal Volume </span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="add-conference-proceedings.php">
                                            <span class="title"> Create Conference Proceedings </span>
                                        </a>
                                    </li>
                                </ul>
                            </li>
                            <li>
								<a href="javascript:void(0)">
									<div class="item-content">
										<div class="item-media">
											<i class="ti-files"></i>
										</div>
										<div class="item-inner">
											<span class="title"> Reports </span><i class="icon-arrow"></i>
										</div>
									</div>
								</a>
								<ul class="sub-menu">
									
                                    <li>
                                        <a href="show-frequent-borrowers.php">
                                            <span class="title"> Frequent Borrowers </span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="show-most-borrowed-docs.php">
                                            <span class="title"> Most Borrowed Docs </span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="show-popular-docs-in-year.php">
                                            <span class="title"> Books of the year </span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="show-avg-fine-in-period.php">
                                            <span class="title"> Show Average Fine </span>
                                        </a>
                                    </li>
								
								</ul>
                            </li>

						</ul>
						<!-- end: CORE FEATURES -->
						
					</nav>
					</div>
			</div>
