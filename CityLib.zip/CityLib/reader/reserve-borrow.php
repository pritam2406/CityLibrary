<?php
include('../DataManager/ReaderHelper.php');
$reserveNumber = $_GET['reserveNo'];
$RID = $_GET['rid'];
ReaderHelper::borrowReservedDocs($reserveNumber, $RID);
header('location:reader-reserve-list.php');
?>
