<?php
include('../DataManager/ReaderHelper.php');
$RID = $_GET['rid'];
ReaderHelper::deleteReader($RID);
header('location:reader-borrow-list.php');
?>
